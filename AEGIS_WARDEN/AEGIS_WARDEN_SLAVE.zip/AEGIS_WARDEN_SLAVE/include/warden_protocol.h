#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum : uint8_t
{
    WARDEN_CMD_CLEAR = 0,
    WARDEN_CMD_FIRE = 1,
    WARDEN_CMD_SMOKE = 2,
    WARDEN_CMD_FIRE_SMOKE = 3

} warden_command_t;


/*
 * WARDEN ESP-NOW PACKET
 *
 * MUST BE IDENTICAL ON MASTER AND SLAVE.
 *
 * Total size:
 *
 * version                  1
 * source                   1
 * command                  1
 * reserved                 1
 * sequence                 2
 * fire confidence          2
 * smoke confidence         2
 *
 * TOTAL = 10 BYTES
 */

typedef struct __attribute__((packed))
{
    uint8_t  version;
    uint8_t  source;
    uint8_t  command;
    uint8_t  reserved;

    uint16_t sequence;

    uint16_t fire_confidence_x1000;
    uint16_t smoke_confidence_x1000;

} warden_packet_t;


/*
 * Protocol version
 */
#define WARDEN_PROTOCOL_VERSION 1


/*
 * MASTER source ID
 *
 * The ESP32-S3 Warden Master sends packets
 * with source = 2.
 */
#define WARDEN_SOURCE_ID 2


#ifdef __cplusplus
}
#endif